import 'package:flutter_test/flutter_test.dart';
import 'package:weather_app/services/premium.dart';

void main() {
  group('PremiumRules — free city limit', () {
    test('free user can save up to 3 cities', () {
      expect(
        PremiumRules.canAddCity(savedCityCount: 0, isPremium: false),
        isTrue,
      );
      expect(
        PremiumRules.canAddCity(savedCityCount: 2, isPremium: false),
        isTrue,
      );
      expect(
        PremiumRules.canAddCity(savedCityCount: 3, isPremium: false),
        isFalse,
      );
    });

    test('free user at the limit cannot add a 4th city', () {
      expect(
        PremiumRules.canAddCity(savedCityCount: 4, isPremium: false),
        isFalse,
      );
    });

    test('Premium user can save unlimited cities', () {
      expect(
        PremiumRules.canAddCity(savedCityCount: 3, isPremium: true),
        isTrue,
      );
      expect(
        PremiumRules.canAddCity(savedCityCount: 50, isPremium: true),
        isTrue,
      );
    });

    test('the free limit is 3 saved cities', () {
      expect(PremiumRules.freeCityLimit, 3);
    });
  });

  group('PremiumRules — 7-day forecast', () {
    test('forecast is locked for free users', () {
      expect(
        PremiumRules.isForecastLocked(isPremium: false),
        isTrue,
      );
    });

    test('forecast is open for Premium users', () {
      expect(
        PremiumRules.isForecastLocked(isPremium: true),
        isFalse,
      );
    });
  });

  group('PremiumRules — product ids', () {
    test('monthly and lifetime ids are the ones Play Console will use', () {
      expect(PremiumRules.monthlyProductId, 'weather_premium_monthly');
      expect(PremiumRules.lifetimeProductId, 'weather_premium_lifetime');
      expect(PremiumRules.productIds, {
        'weather_premium_monthly',
        'weather_premium_lifetime',
      });
    });
  });

  group('PremiumEntitlement', () {
    test('round-trips through JSON', () {
      final grantedAt = DateTime(2026, 11, 14, 12, 0);
      final entitlement = PremiumEntitlement(
        productId: 'weather_premium_lifetime',
        grantedAt: grantedAt,
      );
      final restored =
          PremiumEntitlement.fromJson(entitlement.toJson());
      expect(restored.productId, 'weather_premium_lifetime');
      expect(restored.grantedAt, grantedAt);
      expect(restored.isValid, isTrue);
    });

    test('an unknown product id is not valid', () {
      final entitlement = PremiumEntitlement(
        productId: 'something_else',
        grantedAt: DateTime.now(),
      );
      expect(entitlement.isValid, isFalse);
    });

    test('bad saved data does not crash and is not valid', () {
      final entitlement = PremiumEntitlement.fromJson({});
      expect(entitlement.isValid, isFalse);
    });
  });
}
