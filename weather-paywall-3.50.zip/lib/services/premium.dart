/// Premium rules for the Weather App — pure Dart, no store access.
///
/// Free tier: current conditions, hourly forecast, the GPS city, and up to
/// [freeCityLimit] saved cities.
/// Premium tier: unlimited saved cities + the 7-day forecast.
///
/// Premium can be bought two ways, same unlock either way:
/// - `weather_premium_monthly`: $0.99/month subscription. The 7-day free
///   trial is configured on the subscription in Google Play Console —
///   there is no trial logic in this code.
/// - `weather_premium_lifetime`: $10 one-time purchase, yours forever.
///
/// There are NO ads in this app, ever.
class PremiumRules {
  /// Product id for the $0.99/month subscription.
  static const monthlyProductId = 'weather_premium_monthly';

  /// Product id for the $10 one-time lifetime license.
  static const lifetimeProductId = 'weather_premium_lifetime';

  /// Both product ids the store is asked about.
  static const productIds = {monthlyProductId, lifetimeProductId};

  /// How many cities a free user can save (the GPS city never counts).
  static const freeCityLimit = 3;

  /// Can this user save one more city?
  /// [savedCityCount] counts saved cities only — the GPS city is not saved
  /// and never counts toward the limit.
  static bool canAddCity({
    required int savedCityCount,
    required bool isPremium,
  }) {
    if (isPremium) return true;
    return savedCityCount < freeCityLimit;
  }

  /// Is the 7-day forecast locked for this user?
  static bool isForecastLocked({required bool isPremium}) => !isPremium;
}

/// A saved record that this device owns Premium.
///
/// Kept in SharedPreferences so a paying user stays Premium even when the
/// store can't be reached (offline, or the app isn't on the store yet).
/// A record only ever exists because a real purchase (or restore) created
/// it — with no record and no store confirmation, the user is free tier.
class PremiumEntitlement {
  const PremiumEntitlement({
    required this.productId,
    required this.grantedAt,
  });

  /// The product that granted Premium: one of [PremiumRules.productIds].
  final String productId;

  /// When the purchase (or restore) happened.
  final DateTime grantedAt;

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'grantedAt': grantedAt.toIso8601String(),
      };

  factory PremiumEntitlement.fromJson(Map<String, dynamic> json) {
    final productId = json['productId'] as String? ?? '';
    final grantedAtRaw = json['grantedAt'] as String? ?? '';
    return PremiumEntitlement(
      productId: productId,
      grantedAt:
          DateTime.tryParse(grantedAtRaw) ?? DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  /// True only for a record that names one of our two products.
  bool get isValid => PremiumRules.productIds.contains(productId);
}
